var doing = false;
var spin = [new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3")];
var coin = [new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3")]
var win = new Audio("res/sounds/win.mp3");
var lose = new Audio("res/sounds/lose.mp3");
var audio = false;
let status = document.getElementById("status")
var info = true;

function doslot() {
    if (Amount === 0) {
        console.log("Enter Amount")
    } else if (betstored === 0) {
        console.log("Enter bet ")
    } else {
        if (doing) {
            return null;
        }
        doing = true;
        var numChanges = randomInt(1, 4) * 7;
        var numeberSlot1 = numChanges + randomInt(1, 7);
        var numeberSlot2 = numChanges + 2 * 7 + randomInt(1, 7);
        var numeberSlot3 = numChanges + 4 * 7 + randomInt(1, 7);

        var i1 = 0;
        var i2 = 0;
        var i3 = 0;
        var sound = 0;

        status.innerHTML = "SPINNING";
        slot1 = setInterval(spin1, 50);
        slot2 = setInterval(spin2, 50);
        slot3 = setInterval(spin3, 50);

        function spin1() {
            i1++;
            if (i1 >= numeberSlot1) {
                coin[0].play();
                clearInterval(slot1);
                return null;
            }
            slotTile = document.getElementById("slot1");
            if (slotTile.className == "a7") {
                slotTile.className = "a0";
            }
            slotTile.className = "a" + (parseInt(slotTile.className.substring(1)) + 1);
        }

        function spin2() {
            i2++;
            if (i2 >= numeberSlot2) {
                coin[1].play();
                clearInterval(slot2);
                return null;
            }
            slotTile = document.getElementById("slot2");
            if (slotTile.className == "a7") {
                slotTile.className = "a0";
            }
            slotTile.className = "a" + (parseInt(slotTile.className.substring(1)) + 1);
        }

        function spin3() {
            i3++;
            if (i3 >= numeberSlot3) {
                coin[2].play();
                clearInterval(slot3);
                testWin();
                return null;
            }
            slotTile = document.getElementById("slot3");
            if (slotTile.className == "a7") {
                slotTile.className = "a0";
            }
            sound++;
            if (sound == spin.length) {
                sound = 0;
            }
            spin[sound].play();
            slotTile.className = "a" + (parseInt(slotTile.className.substring(1)) + 1);
        }
    }
}
function testWin() {
    var slot1 = document.getElementById("slot1").className;
    var slot2 = document.getElementById("slot2").className;
    var slot3 = document.getElementById("slot3").className;
    if ((slot1 === slot2 && slot2 === slot3)){
        if(slot1==="a7" && slot2==="a7" && slot3==="a7"){
            let bet = betstored **7;
        Amount += bet; 
        status.innerHTML = "YOU WIN! Winnings: " + bet;
        document.querySelector(".amountstored").innerText = Amount;
		betstored = 0;
        win.play();
        }else{
            let bet = betstored **2;
        Amount += bet; 
        status.innerHTML = "YOU WIN! Winnings: " + bet;
        document.querySelector(".amountstored").innerText = Amount;
		betstored = 0;
        win.play();
        }
    }else if((slot1 === "a1" && slot2 === "a1" && slot3 === "a7") ||
    (slot1 === "a2" && slot2 === "a2" && slot3 === "a7") ||
    (slot1 === "a3" && slot2 === "a3" && slot3 === "a7") ||
    (slot1 === "a4" && slot2 === "a4" && slot3 === "a7") ||
    (slot1 === "a5" && slot2 === "a5" && slot3 === "a7") ||
    (slot1 === "a6" && slot2 === "a6" && slot3 === "a7")) {
        
        let bet = betstored * 7;
        Amount += bet; 
        status.innerHTML = "YOU WIN! Winnings: " + bet;
        document.querySelector(".amountstored").innerText = Amount;
		betstored = 0;
        win.play();
    } else {
        status.innerHTML = "YOU LOSE!";
		Amount -= betstored;
		betstored = 0;
		document.querySelector(".amountstored").innerText = Amount;
        lose.play();
        checking();
    }
    doing = false;
}

function randomInt(min, max){
	return Math.floor((Math.random() * (max-min+1)) + min);
}

let Amount = 0;
function submitAmount() {
    var amount = document.getElementById("amount").value;
    var amountInt = parseInt(amount);

    if (isNaN(amountInt) || amountInt <= 0) {
        alert("Please enter a valid positive integer amount.");
        return;
    }
    Amount = amountInt;
    document.getElementById("amount").value = "";
    document.querySelector(".amountstored").innerText = Amount;
    document.getElementById("enterAmount").style.display = "none";
    document.getElementById("gameInterface").style.display = "block";

    const button = document.querySelector('.buttonamount');
    const message = document.getElementById('message');

    // Change button color to green
    button.style.backgroundColor = '#00FF00'; // Green color

    // Change button text to check icon
    button.innerHTML = '<span class="check-icon">✓</span>';

    // Revert button color and text after 2 seconds
    setTimeout(() => {
        button.style.backgroundColor = '#FFD700'; // Reset button color
        button.innerHTML = 'Submit Amount'; // Reset button text
    }, 2000);

    // Display message
    message.textContent = 'Submission confirmed!';
    setTimeout(() => {
        message.textContent = ''; // Clear message
    }, 2000);
}


let betstored = 0;
function betcoin() {
    let betAmount = parseInt(document.getElementById("Betcoin").value);
    if (isNaN(betAmount) || betAmount <= 0) {
        alert("Please enter a valid bet amount greater than zero.");
        return;
    }
    if (betAmount > Amount || betAmount <= 5) {
        alert("Not enough balance or invalid bet amount!");
        document.getElementById("Betcoin").value = "";
        return;
    }
    betstored = betAmount;
    document.querySelector(".amountstored").innerText = Amount;
    document.getElementById("Betcoin").value = "";
    console.log("Bet placed: ", betAmount);
    console.log("Remaining balance: ", Amount);
	document.getElementById("finalcon").style.display = "none";
    document.getElementById("spinButton").style.display = "flex";
}


function checking(){
    if (Amount === 0 ){
        document.getElementById("enterAmount").style.display = "flex";
        document.getElementById("gameInterface").style.display = "none"
    }
    
}

function changeImage() {
    const images = ['img/image1.jpg', 'img/image2.jpg', 'img/image3.jpg', 'img/image4.jpg', 'img/image5.jpg', 'img/image6.jpg', 'img/image7.jpg']; // Array of image paths
    let currentImageIndex = 0;

    function changeImageSource() {
        const imageElement = document.getElementById('slotImage');
        imageElement.src = images[currentImageIndex];
        currentImageIndex = (currentImageIndex + 1) % images.length; // Loop through the images
    }

    setInterval(changeImageSource, 2000); // Change image every 2 seconds
}

// Call the function to start changing images
changeImage();

