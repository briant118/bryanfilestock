function submitAmount() {
    const button = document.querySelector('button');
    const message = document.getElementById('message');

    // Change button color to green
    button.style.backgroundColor = '#00FF00'; // Green color

    // Change button text to check icon
    button.innerHTML = '<span class="check-icon">✓</span>';

    // Revert button color and text after 2 seconds
    setTimeout(() => {
        button.style.backgroundColor = '#FFD700'; // Reset button color
        button.innerHTML = 'Submit Amount'; // Reset button text
    }, 2000);

    // Display message
    message.textContent = 'Submission confirmed!';
    setTimeout(() => {
        message.textContent = ''; // Clear message
    }, 2000);
}

function changeImage() {
    const images = ['image1.jpg', 'image2.jpg', 'image3.jpg', 'image4.jpg', 'image5.jpg', 'image6.jpg', 'image7.jpg']; // Array of image paths
    let currentImageIndex = 0;

    function changeImageSource() {
        const imageElement = document.getElementById('slotImage');
        imageElement.src = images[currentImageIndex];
        currentImageIndex = (currentImageIndex + 1) % images.length; // Loop through the images
    }

    setInterval(changeImageSource, 2000); // Change image every 2 seconds
}

// Call the function to start changing images
changeImage();