var doing = false;
var spin = [new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3"),new Audio("res/sounds/spin.mp3")];
var coin = [new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3"),new Audio("res/sounds/coin.mp3")]
var win = new Audio("res/sounds/win.mp3");
var lose = new Audio("res/sounds/lose.mp3");
var audio = false;
let status = document.getElementById("status")
var info = true;
let amountElement = document.getElementById("amount");
let betamount = 0;
let amount = parseInt(localStorage.getItem('Amount')) || 0;



function getValue(value) {
    betamount = value;
    return value;
}

function ok() {
    if (betamount > amount) {
        alert("Not enough balance!");
    } else {
        document.getElementById('btm').innerHTML = betamount
        amountElement.textContent = amount;
        console.log(amount);
        console.log(betamount);
        return amount;
    }
}

function cancel() {
    betamount = 0;
    document.getElementById('btm').innerHTML = betamount
    console.log(betamount);
    return betamount;
}


function testWin() {
    var slot1 = document.getElementById("slot1").className;
    var slot2 = document.getElementById("slot2").className;
    var slot3 = document.getElementById("slot3").className;
    if ((slot1 === slot2 && slot2 === slot3)){
        if(slot1==="a7" && slot2==="a7" && slot3==="a7"){
            let bet = betamount **7;
        amount += bet; 
        status.innerHTML = "YOU WIN! Winnings: " + betamount;
        document.getElementById('amount').innerText = amount;
		betamount = 0;
        win.play();
        }else{
            let bet = betamount **2;
        amount += bet; 
        status.innerHTML = "YOU WIN! Winnings: " + betamount;
        document.getElementById('amount').innerText = amount;
		betamount = 0;
        win.play();
        }
    }else if((slot1 === "a1" && slot2 === "a1" && slot3 === "a7") ||
    (slot1 === "a2" && slot2 === "a2" && slot3 === "a7") ||
    (slot1 === "a3" && slot2 === "a3" && slot3 === "a7") ||
    (slot1 === "a4" && slot2 === "a4" && slot3 === "a7") ||
    (slot1 === "a5" && slot2 === "a5" && slot3 === "a7") ||
    (slot1 === "a6" && slot2 === "a6" && slot3 === "a7")) {
        
        let bet = betamount * 7;
        amount += bet; 
        status.innerHTML = "YOU WIN! Winnings: " + bet;
        document.getElementById('amount').innerText = amount;
		betamount = 0;
        win.play();
    } else {
        status.innerHTML = "YOU LOSE!";
		amount -= betamount;
		betamount = 0;
		document.getElementById('amount').innerText = amount;
        document.getElementById('btm').innerHTML = betamount
        lose.play();
        
    }
    doing = false;
}

function randomInt(min, max){
	return Math.floor((Math.random() * (max-min+1)) + min);
}

function doslot() {
    if (amount === 0) {
        alert("Enter Amount")
    } else if (betamount === 0) {
        alert("Enter bet ")
    } else {
        if (doing) {
            return null;
        }
        doing = true;
        var numChanges = randomInt(1, 4) * 7;
        var numeberSlot1 = numChanges + randomInt(1, 7);
        var numeberSlot2 = numChanges + 2 * 7 + randomInt(1, 7);
        var numeberSlot3 = numChanges + 4 * 7 + randomInt(1, 7);

        var i1 = 0;
        var i2 = 0;
        var i3 = 0;
        var sound = 0;

        status.innerHTML = "SPINNING";
        slot1 = setInterval(spin1, 50);
        slot2 = setInterval(spin2, 50);
        slot3 = setInterval(spin3, 50);

        function spin1() {
            i1++;
            if (i1 >= numeberSlot1) {
                coin[0].play();
                clearInterval(slot1);
                return null;
            }
            slotTile = document.getElementById("slot1");
            if (slotTile.className == "a7") {
                slotTile.className = "a0";
            }
            slotTile.className = "a" + (parseInt(slotTile.className.substring(1)) + 1);
        }

        function spin2() {
            i2++;
            if (i2 >= numeberSlot2) {
                coin[1].play();
                clearInterval(slot2);
                return null;
            }
            slotTile = document.getElementById("slot2");
            if (slotTile.className == "a7") {
                slotTile.className = "a0";
            }
            slotTile.className = "a" + (parseInt(slotTile.className.substring(1)) + 1);
        }

        function spin3() {
            i3++;
            if (i3 >= numeberSlot3) {
                coin[2].play();
                clearInterval(slot3);
                testWin();
                return null;
            }
            slotTile = document.getElementById("slot3");
            if (slotTile.className == "a7") {
                slotTile.className = "a0";
            }
            sound++;
            if (sound == spin.length) {
                sound = 0;
            }
            spin[sound].play();
            slotTile.className = "a" + (parseInt(slotTile.className.substring(1)) + 1);
        }
    }
}

    
    
  

const firstname = localStorage.getItem('first-name')
const lastname = localStorage.getItem('last-name')
let getvalue = parseInt(localStorage.getItem('Amount'))
document.getElementById('first-name').textContent =  firstname + lastname 
document.getElementById('amount').textContent = getvalue

